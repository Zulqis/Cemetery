<?php include '../template/header_admin.php'; ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small>Argao Cemetery admin panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="callout callout-info">
          <h4>Hello! <?php echo $_SESSION['username']?>, </h4>
            <p>Welcome to Argao Cemetery admin page</p>
            <p>You can use this page for:.
              <br/>Create new admin
              <br/>Create cemetery data
            </p>
          </div>
          
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php include '../template/footer.php'; ?>